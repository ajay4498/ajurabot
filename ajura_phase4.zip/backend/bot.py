import os
from flask import Flask, request, jsonify
import openai
import json
from gtts import gTTS
import speech_recognition as sr

# Load environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")

openai.api_key = OPENAI_API_KEY

app = Flask(__name__)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get("message", "")
    
    response = openai.ChatCompletion.create(
        model="gpt-4-turbo",
        messages=[{"role": "system", "content": "You are a human-like AI assistant."},
                  {"role": "user", "content": user_message}]
    )
    
    return jsonify({"response": response["choices"][0]["message"]["content"]})

@app.route('/tts', methods=['POST'])
def text_to_speech():
    data = request.json
    text = data.get("text", "")
    tts = gTTS(text=text, lang="en")
    tts.save("response.mp3")
    return jsonify({"audio": "response.mp3"})

@app.route('/stt', methods=['POST'])
def speech_to_text():
    recognizer = sr.Recognizer()
    with sr.AudioFile("input.wav") as source:
        audio_data = recognizer.record(source)
        text = recognizer.recognize_google(audio_data)
    return jsonify({"text": text})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
