async function sendMessage() {
    let userInput = document.getElementById("user-input").value;
    document.getElementById("chat-box").innerHTML += "<p><b>You:</b> " + userInput + "</p>";
    
    let response = await fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userInput })
    });
    
    let data = await response.json();
    document.getElementById("chat-box").innerHTML += "<p><b>Ajura:</b> " + data.response + "</p>";
}